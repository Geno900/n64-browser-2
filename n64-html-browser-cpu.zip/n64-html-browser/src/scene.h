#ifndef SCENE_H
#define SCENE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "input.h"

#define MAX_BOXES    96
#define MAX_PICKUPS  16

typedef struct { float x, y, z, w, h, d; uint32_t col; } SceneBox;   /* x,z = center, y = base */
typedef struct { float x, z; uint32_t col; bool taken; } Pickup;

typedef struct {
    char  name[24];
    char  caption[40];
    SceneBox boxes[MAX_BOXES];   int n_boxes;
    Pickup   pickups[MAX_PICKUPS]; int n_pickups;
    float start_x, start_z, start_yaw;
    float floor_size;
    uint32_t floor_col, sky_col, ceil_col;
    bool has_ceiling;
} Scene;

void scene_init(Scene *s);
/* Called by the HTML parser for every tag found between <scene> and </scene>. */
bool scene_tag(Scene *s, const char *name, const char *attrs, size_t alen);

void scene_start(Scene *s);
/* Returns false when the player leaves the scene (B button). */
bool scene_update(Scene *s, const Input *in, float dt);
void scene_draw(surface_t *d, Scene *s);

#endif
