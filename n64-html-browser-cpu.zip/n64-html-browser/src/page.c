/* Streaming HTML tokenizer + layout engine.
 * Walks the source once and emits positioned Items; there is no DOM, which
 * keeps memory use tiny (important with 4 MB of RAM). */
#include "page.h"
#include "util.h"
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

/* ---------------------------------------------------------------- storage */

static void *xgrow(void *p, int *cap, int need, size_t elem)
{
    if (need <= *cap) return p;
    int nc = *cap ? *cap : 64;
    while (nc < need) nc *= 2;
    void *np = realloc(p, (size_t)nc * elem);
    assert(np);
    *cap = nc;
    return np;
}

/* Copies text into the arena. Byte 0x01 is our internal non-breaking space. */
static uint32_t arena_put(Page *pg, const char *s, int len, bool upper)
{
    size_t need = pg->arena_len + (size_t)len + 1;
    if (need > pg->arena_cap) {
        size_t nc = pg->arena_cap ? pg->arena_cap : 4096;
        while (nc < need) nc *= 2;
        pg->arena = realloc(pg->arena, nc);
        assert(pg->arena);
        pg->arena_cap = nc;
    }
    uint32_t off = (uint32_t)pg->arena_len;
    for (int i = 0; i < len; i++) {
        char c = s[i];
        if (c == 1) c = ' ';
        else if (upper && c >= 'a' && c <= 'z') c -= 32;
        pg->arena[off + i] = c;
    }
    pg->arena[off + len] = 0;
    pg->arena_len = need;
    return off;
}

static Item *add_item(Page *pg)
{
    pg->items = xgrow(pg->items, &pg->cap_items, pg->n_items + 1, sizeof(Item));
    Item *it = &pg->items[pg->n_items++];
    memset(it, 0, sizeof *it);
    it->link = -1;
    it->aux = -1;
    return it;
}

static int new_link(Page *pg, const char *href)
{
    pg->links = xgrow(pg->links, &pg->cap_links, pg->n_links + 1, sizeof(Link));
    Link *l = &pg->links[pg->n_links];
    l->href_off = arena_put(pg, href, (int)strlen(href), false);
    l->y0 = INT16_MAX;
    l->y1 = -1;
    return pg->n_links++;
}

static void extend_link(Page *pg, int link, int y, int h)
{
    Link *l = &pg->links[link];
    if (y < l->y0) l->y0 = (int16_t)y;
    if (y + h > l->y1) l->y1 = (int16_t)(y + h);
}

/* ------------------------------------------------------------ layout state */

typedef struct {
    Page *pg;
    int  y, col, left, width_cols, gap;
    bool line_open, pending_space, has_content;
    int  line_first;
    int  align, base_align;                 /* 0 left, 1 center */
    int  bold, ital, under, code, upper, pre;
    bool pre_first;
    int  cur_link;
    int  list_depth; bool list_ol[8]; int list_n[8];
    int  quote_depth; int quote_y0[4];
    bool in_title, in_head;
    Scene *scene;
} Lay;

#define DEC(v) do { if ((v) > 0) (v)--; } while (0)

static void start_line(Lay *L)
{
    if (L->gap && L->has_content) L->y += L->gap;
    L->gap = 0;
    L->line_open = true;
    L->line_first = L->pg->n_items;
    L->col = 0;
}

static void end_line(Lay *L)
{
    if (!L->line_open) return;
    Page *pg = L->pg;
    if (L->align == 1 && !L->pre) {
        int avail = (L->width_cols - L->left) * CHAR_W;
        int shift = (avail - L->col * CHAR_W) / 2;
        if (shift > 0)
            for (int i = L->line_first; i < pg->n_items; i++)
                if (pg->items[i].type == IT_TEXT) pg->items[i].x += shift;
    }
    L->y += LINE_H;
    L->line_open = false;
    L->col = 0;
    L->pending_space = false;
    L->has_content = true;
}

static void blank_line(Lay *L)
{
    if (L->gap && L->has_content) L->y += L->gap;
    L->gap = 0;
    L->y += LINE_H;
    L->has_content = true;
}

static void block_break(Lay *L, int gap)
{
    end_line(L);
    if (gap > L->gap) L->gap = gap;
}

static uint8_t cur_flags(const Lay *L)
{
    uint8_t f = 0;
    if (L->bold)  f |= F_BOLD;
    if (L->ital)  f |= F_ITALIC;
    if (L->under) f |= F_UNDER;
    if (L->code)  f |= F_CODE;
    return f;
}

static void put_word(Lay *L, const char *w, int len)
{
    Page *pg = L->pg;
    int avail = L->width_cols - L->left;
    if (avail < 4) avail = 4;

    while (len > 0) {
        int space = (L->line_open && L->col > 0 && L->pending_space) ? 1 : 0;
        if (L->col > 0 && L->col + space + len > avail) { end_line(L); continue; }
        if (!L->line_open) start_line(L);

        int n = len;
        if (L->col + space + n > avail) n = avail - L->col - space;   /* hard break */
        if (n < 1) n = 1;

        /* Inside a link, fold the separating space into the item so the
         * underline and focus highlight stay continuous. */
        bool lead = false;
        if (space && L->cur_link >= 0 && pg->n_items > 0) {
            const Item *last = &pg->items[pg->n_items - 1];
            lead = last->type == IT_TEXT && last->link == L->cur_link && last->y == L->y;
        }

        char tmp[104];
        int tl = n;
        if (lead) { tmp[0] = 1; memcpy(tmp + 1, w, n); tl = n + 1; }
        else memcpy(tmp, w, n);

        int xcol = L->col + ((space && !lead) ? 1 : 0);
        uint32_t off = arena_put(pg, tmp, tl, L->upper > 0);
        Item *it = add_item(pg);
        it->type = IT_TEXT;
        it->flags = cur_flags(L);
        it->x = (int16_t)(MARGIN_X + (L->left + xcol) * CHAR_W);
        it->y = (int16_t)L->y;
        it->len = (uint16_t)tl;
        it->off = off;
        it->link = (int16_t)L->cur_link;
        if (L->cur_link >= 0) extend_link(pg, L->cur_link, L->y, LINE_H);

        L->col += space + n;
        w += n;
        len -= n;
        L->pending_space = false;
        if (len > 0) end_line(L);
    }
}

static void put_raw(Lay *L, const char *s, int n)
{
    if (n <= 0) return;
    Page *pg = L->pg;
    if (!L->line_open) start_line(L);
    if (L->col > 120) return;
    uint32_t off = arena_put(pg, s, n, false);
    Item *it = add_item(pg);
    it->type = IT_TEXT;
    it->flags = cur_flags(L);
    it->x = (int16_t)(MARGIN_X + (L->left + L->col) * CHAR_W);
    it->y = (int16_t)L->y;
    it->len = (uint16_t)n;
    it->off = off;
    it->link = (int16_t)L->cur_link;
    if (L->cur_link >= 0) extend_link(pg, L->cur_link, L->y, LINE_H);
    L->col += n;
}

/* Rules, images and scene boxes: whole-line blocks. */
static Item *emit_block(Lay *L, ItemType type, int w, int h, int link)
{
    Page *pg = L->pg;
    end_line(L);
    if (L->gap && L->has_content) L->y += L->gap;
    L->gap = 0;
    int avail = (L->width_cols - L->left) * CHAR_W;
    int x = MARGIN_X + L->left * CHAR_W;
    if (L->align == 1 && w < avail) x += (avail - w) / 2;
    Item *it = add_item(pg);
    it->type = (uint8_t)type;
    it->x = (int16_t)x;
    it->y = (int16_t)L->y;
    it->w = (int16_t)w;
    it->h = (int16_t)h;
    it->link = (int16_t)link;
    if (link >= 0) extend_link(pg, link, L->y, h);
    L->y += h;
    L->gap = 4;
    L->has_content = true;
    return it;
}

static void add_anchor(Lay *L, const char *name)
{
    Page *pg = L->pg;
    int y = L->y + ((!L->line_open && L->has_content) ? L->gap : 0);
    pg->anchors = xgrow(pg->anchors, &pg->cap_anchors, pg->n_anchors + 1, sizeof(Anchor));
    Anchor *a = &pg->anchors[pg->n_anchors++];
    a->name_off = arena_put(pg, name, (int)strlen(name), false);
    a->y = (int16_t)y;
}

/* ------------------------------------------------------------------- text */

static const char *decode_entity(const char *s, size_t n, size_t *used, char *buf)
{
    static const struct { const char *n; const char *r; } ents[] = {
        {"amp", "&"}, {"lt", "<"}, {"gt", ">"}, {"quot", "\""}, {"apos", "'"},
        {"nbsp", "\x01"}, {"copy", "(c)"}, {"reg", "(R)"}, {"hellip", "..."},
        {"mdash", "--"}, {"ndash", "-"}, {"bull", "*"}, {"laquo", "<<"},
        {"raquo", ">>"}, {"middot", "."}, {"larr", "<-"}, {"rarr", "->"},
    };
    size_t i = 1;
    while (i < n && i < 10 && s[i] != ';' && !isspace((unsigned char)s[i]) && s[i] != '&' && s[i] != '<') i++;
    if (i >= n || s[i] != ';') { *used = 1; buf[0] = '&'; buf[1] = 0; return buf; }

    char name[12];
    size_t nl = i - 1;
    if (nl == 0 || nl >= sizeof name) { *used = 1; buf[0] = '&'; buf[1] = 0; return buf; }
    memcpy(name, s + 1, nl);
    name[nl] = 0;
    *used = i + 1;

    if (name[0] == '#') {
        long v = (name[1] == 'x' || name[1] == 'X') ? strtol(name + 2, NULL, 16) : strtol(name + 1, NULL, 10);
        buf[0] = (v == 160) ? 1 : (v >= 32 && v < 127) ? (char)v : '?';
        buf[1] = 0;
        return buf;
    }
    for (size_t k = 0; k < sizeof ents / sizeof ents[0]; k++)
        if (!strcmp(name, ents[k].n)) return ents[k].r;
    buf[0] = '?'; buf[1] = 0;
    return buf;
}

static void title_append(Lay *L, const char *s, size_t n)
{
    Page *pg = L->pg;
    size_t len = strlen(pg->title);
    bool sp_pending = false;
    for (size_t i = 0; i < n && len < sizeof pg->title - 1; i++) {
        unsigned char c = (unsigned char)s[i];
        if (isspace(c)) { sp_pending = len > 0; continue; }
        if (sp_pending && len < sizeof pg->title - 2) pg->title[len++] = ' ';
        sp_pending = false;
        pg->title[len++] = (c >= 32 && c < 127) ? (char)c : '?';
    }
    pg->title[len] = 0;
}

static void handle_text(Lay *L, const char *s, size_t n)
{
    if (L->in_title) { title_append(L, s, n); return; }
    if (L->in_head || L->scene) return;

    char word[96]; int wl = 0;
    char seg[128]; int sl = 0;

    for (size_t i = 0; i < n; ) {
        char ebuf[4];
        const char *chars;
        char one[2];
        if (s[i] == '&') {
            size_t used;
            chars = decode_entity(s + i, n - i, &used, ebuf);
            i += used;
        } else {
            unsigned char c = (unsigned char)s[i++];
            one[0] = (c >= 128) ? '?' : (char)c;
            one[1] = 0;
            chars = one;
        }

        for (const char *p = chars; *p; p++) {
            char ch = *p;
            if (L->pre) {
                if (L->pre_first && ch == '\n') { L->pre_first = false; continue; }
                L->pre_first = false;
                if (ch == '\r') continue;
                if (ch == '\n') {
                    put_raw(L, seg, sl); sl = 0;
                    if (L->line_open) end_line(L); else blank_line(L);
                    continue;
                }
                if (ch == '\t') {
                    for (int k = 0; k < 4 && sl < 127; k++) seg[sl++] = ' ';
                    continue;
                }
                if (ch == 1) ch = ' ';
                if (sl < 127) seg[sl++] = ch;
                if (sl >= 127) { put_raw(L, seg, sl); sl = 0; }
            } else if (isspace((unsigned char)ch)) {
                if (wl) { put_word(L, word, wl); wl = 0; }
                L->pending_space = true;
            } else {
                word[wl++] = ch;
                if (wl >= 95) { put_word(L, word, wl); wl = 0; }
            }
        }
    }
    if (wl) put_word(L, word, wl);
    if (sl) put_raw(L, seg, sl);
}

/* ------------------------------------------------------------------- tags */

static int attr_align(const char *a, size_t n, int def)
{
    char b[16];
    if (!attr_get(a, n, "align", b, sizeof b)) return def;
    if (!strcasecmp(b, "center")) return 1;
    return 0;
}

static sprite_t *load_sprite(const char *src)
{
    char path[96], base[64];
    strncpy(base, src, sizeof base - 1);
    base[sizeof base - 1] = 0;
    char *dot = strrchr(base, '.');
    if (dot && (!strcasecmp(dot, ".png") || !strcasecmp(dot, ".gif") || !strcasecmp(dot, ".jpg"))) *dot = 0;
    else if (dot && !strcasecmp(dot, ".sprite")) *dot = 0;
    snprintf(path, sizeof path, "rom:/%s.sprite", base);
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fclose(f);
    return sprite_load(path);
}

static void handle_tag(Lay *L, const char *name, bool closing, const char *a, size_t an)
{
    Page *pg = L->pg;
#define IS(s) (strcmp(name, s) == 0)

    bool selfclose = false;
    for (size_t k = an; k > 0; k--) {
        if (isspace((unsigned char)a[k - 1])) continue;
        selfclose = a[k - 1] == '/';
        break;
    }

    /* Inside <scene>: only scene children are interpreted. */
    if (L->scene) {
        if (closing && IS("scene")) L->scene = NULL;
        else if (!closing) scene_tag(L->scene, name, a, an);
        return;
    }

    if (!closing) {
        char id[32];
        if (attr_get(a, an, "id", id, sizeof id)) add_anchor(L, id);
        else if (IS("a") && attr_get(a, an, "name", id, sizeof id)) add_anchor(L, id);
    }

    if (IS("head"))  { L->in_head = !closing; return; }
    if (IS("title")) { L->in_title = !closing; return; }
    if (IS("html") || IS("body") || IS("span") || IS("font") || IS("small") ||
        IS("sup") || IS("sub") || IS("abbr") || IS("section") || IS("article") ||
        IS("header") || IS("footer") || IS("nav") || IS("main") || IS("meta") || IS("link")) return;

    /* headings */
    if (strlen(name) == 2 && name[0] == 'h' && name[1] >= '1' && name[1] <= '6') {
        int lvl = name[1] - '0';
        if (!closing) {
            block_break(L, 6);
            L->align = attr_align(a, an, lvl == 1 ? 1 : L->base_align);
            L->bold++;
            if (lvl <= 2) L->upper++;
        } else {
            block_break(L, 3);
            if (lvl == 1) {
                L->gap = 2;
                emit_block(L, IT_RULE, (L->width_cols - L->left) * CHAR_W, 2, -1)->flags = F_THICK;
            }
            L->align = L->base_align;
            DEC(L->bold);
            if (lvl <= 2) DEC(L->upper);
            L->gap = L->gap < 5 ? 5 : L->gap;
        }
        return;
    }

    if (IS("p") || IS("div")) {
        block_break(L, IS("p") ? 6 : 0);
        L->align = closing ? L->base_align : attr_align(a, an, L->base_align);
        return;
    }
    if (IS("center")) {
        block_break(L, 0);
        L->base_align = L->align = closing ? 0 : 1;
        return;
    }
    if (IS("br")) {
        if (L->line_open) end_line(L); else blank_line(L);
        return;
    }
    if (IS("hr")) {
        if (closing) return;
        if (L->gap < 4) L->gap = 4;
        emit_block(L, IT_RULE, (L->width_cols - L->left) * CHAR_W, 1, -1);
        return;
    }

    if (IS("b") || IS("strong")) { if (closing) DEC(L->bold); else L->bold++; return; }
    if (IS("i") || IS("em") || IS("cite") || IS("dfn")) { if (closing) DEC(L->ital); else L->ital++; return; }
    if (IS("u")) { if (closing) DEC(L->under); else L->under++; return; }
    if (IS("code") || IS("tt") || IS("kbd") || IS("samp")) { if (closing) DEC(L->code); else L->code++; return; }

    if (IS("a")) {
        if (closing) { L->cur_link = -1; return; }
        char href[64];
        if (attr_get(a, an, "href", href, sizeof href)) L->cur_link = new_link(pg, href);
        return;
    }

    if (IS("ul") || IS("ol")) {
        if (!closing) {
            block_break(L, L->list_depth == 0 ? 4 : 0);
            if (L->list_depth < 8) {
                L->list_ol[L->list_depth] = IS("ol");
                L->list_n[L->list_depth] = 0;
                L->list_depth++;
                L->left += 3;
            }
        } else if (L->list_depth > 0) {
            block_break(L, 4);
            L->list_depth--;
            L->left -= 3;
        }
        return;
    }
    if (IS("li")) {
        if (closing || L->list_depth == 0) return;
        end_line(L);
        start_line(L);
        char b[24];
        bool ol = L->list_ol[L->list_depth - 1];
        if (ol) snprintf(b, sizeof b, "%d.", ++L->list_n[L->list_depth - 1]);
        else { b[0] = '*'; b[1] = 0; }
        int bx = MARGIN_X + (L->left - (ol ? 3 : 2)) * CHAR_W;
        Item *it = add_item(pg);
        it->type = IT_TEXT;
        it->x = (int16_t)bx;
        it->y = (int16_t)L->y;
        it->len = (uint16_t)strlen(b);
        it->off = arena_put(pg, b, (int)it->len, false);
        return;
    }
    if (IS("dl")) { block_break(L, 4); return; }
    if (IS("dt")) { if (!closing) block_break(L, 2), L->bold++; else DEC(L->bold); return; }
    if (IS("dd")) {
        block_break(L, 0);
        if (!closing) L->left += 2; else if (L->left >= 2) L->left -= 2;
        return;
    }

    if (IS("blockquote")) {
        if (!closing) {
            block_break(L, 5);
            if (L->quote_depth < 4) {
                L->quote_y0[L->quote_depth++] = L->y + (L->has_content ? L->gap : 0);
                L->left += 2;
            }
        } else if (L->quote_depth > 0) {
            end_line(L);
            L->quote_depth--;
            L->left -= 2;
            int y0 = L->quote_y0[L->quote_depth];
            int h = L->y - y0 - 2;
            if (h > 0) {
                Item *it = add_item(pg);
                it->type = IT_VBAR;
                it->x = (int16_t)(MARGIN_X + L->left * CHAR_W + 2);
                it->y = (int16_t)y0;
                it->w = 2;
                it->h = (int16_t)h;
            }
            block_break(L, 5);
        }
        return;
    }

    if (IS("pre")) {
        if (!closing) { block_break(L, 4); L->pre++; L->code++; L->pre_first = true; }
        else { end_line(L); DEC(L->pre); DEC(L->code); block_break(L, 4); }
        return;
    }

    if (IS("img")) {
        if (closing) return;
        char src[64] = "", alt[48] = "";
        attr_get(a, an, "src", src, sizeof src);
        attr_get(a, an, "alt", alt, sizeof alt);
        sprite_t *spr = NULL;
        int idx = -1;
        if (src[0] && pg->n_images < MAX_IMAGES && (spr = load_sprite(src)) != NULL) {
            idx = pg->n_images;
            pg->images[pg->n_images++] = spr;
        }
        int avail = (L->width_cols - L->left) * CHAR_W;
        int w = spr ? spr->width  : attr_int(a, an, "width", 96);
        int h = spr ? spr->height : attr_int(a, an, "height", 48);
        if (w > avail) w = avail;
        if (w < 16) w = 16;
        if (h < 16) h = 16;
        Item *it = emit_block(L, IT_IMAGE, w, h, L->cur_link);
        it->aux = (int16_t)idx;
        it->len = (uint16_t)strlen(alt);
        it->off = arena_put(pg, alt, (int)it->len, false);
        return;
    }

    if (IS("scene")) {
        if (closing || pg->n_scenes >= MAX_SCENES) return;
        int si = pg->n_scenes++;
        Scene *s = &pg->scenes[si];
        scene_init(s);
        attr_get(a, an, "name", s->name, sizeof s->name);
        if (!attr_get(a, an, "caption", s->caption, sizeof s->caption)) {
            strncpy(s->caption, s->name, sizeof s->caption - 1);
        }
        s->start_x = attr_float(a, an, "startx", 0);
        s->start_z = attr_float(a, an, "startz", 0);
        s->start_yaw = attr_float(a, an, "yaw", 0);
        s->floor_size = attr_float(a, an, "size", s->floor_size);
        s->floor_col = attr_color(a, an, "floor", s->floor_col);
        s->sky_col = attr_color(a, an, "sky", s->sky_col);
        char tmpc[2];
        if (attr_get(a, an, "ceiling", tmpc, sizeof tmpc)) {
            s->has_ceiling = true;
            s->ceil_col = attr_color(a, an, "ceiling", 0x1a1a22);
        }
        char href[32];
        snprintf(href, sizeof href, "scene:%d", si);
        int link = new_link(pg, href);
        int avail = (L->width_cols - L->left) * CHAR_W;
        Item *it = emit_block(L, IT_SCENE, avail, 44, link);
        it->aux = (int16_t)si;
        it->len = (uint16_t)strlen(s->caption);
        it->off = arena_put(pg, s->caption, (int)it->len, false);
        if (!selfclose) L->scene = s;
        return;
    }
#undef IS
}

/* -------------------------------------------------------------- tokenizer */

static const char *find_ci(const char *s, size_t n, const char *needle)
{
    size_t nl = strlen(needle);
    for (size_t i = 0; i + nl <= n; i++)
        if (strncasecmp(s + i, needle, nl) == 0) return s + i;
    return NULL;
}

static void layout_html(Lay *L, const char *src, size_t n)
{
    size_t i = 0;
    while (i < n) {
        if (src[i] != '<') {
            size_t j = i;
            while (j < n && src[j] != '<') j++;
            handle_text(L, src + i, j - i);
            i = j;
            continue;
        }
        if (i + 3 < n && !strncmp(src + i, "<!--", 4)) {
            const char *e = find_ci(src + i + 4, n - i - 4, "-->");
            i = e ? (size_t)(e - src) + 3 : n;
            continue;
        }
        if (i + 1 < n && (src[i + 1] == '!' || src[i + 1] == '?')) {
            while (i < n && src[i] != '>') i++;
            i++;
            continue;
        }

        size_t j = i + 1;
        bool closing = false;
        if (j < n && src[j] == '/') { closing = true; j++; }
        char name[16];
        int nl = 0;
        while (j < n && (isalnum((unsigned char)src[j]) || src[j] == '-')) {
            if (nl < 15) name[nl++] = (char)tolower((unsigned char)src[j]);
            j++;
        }
        name[nl] = 0;
        if (nl == 0) {                      /* a lone '<' in text */
            handle_text(L, "<", 1);
            i++;
            continue;
        }
        size_t astart = j;
        char q = 0;
        while (j < n && (q || src[j] != '>')) {
            if (q) { if (src[j] == q) q = 0; }
            else if (src[j] == '"' || src[j] == '\'') q = src[j];
            j++;
        }
        size_t aend = j;
        if (j < n) j++;
        handle_tag(L, name, closing, src + astart, aend - astart);
        i = j;

        if (!closing && (!strcmp(name, "script") || !strcmp(name, "style"))) {
            char close[20];
            snprintf(close, sizeof close, "</%s", name);
            const char *e = find_ci(src + i, n - i, close);
            if (!e) { i = n; break; }
            i = (size_t)(e - src);
        }
    }
}

/* ------------------------------------------------------------- public API */

void page_init(Page *pg) { memset(pg, 0, sizeof *pg); }

void page_free(Page *pg)
{
    for (int i = 0; i < pg->n_images; i++)
        if (pg->images[i]) sprite_free(pg->images[i]);
    pg->n_images = 0;
    pg->n_items = pg->n_links = pg->n_anchors = pg->n_scenes = 0;
    pg->arena_len = 0;
    pg->title[0] = 0;
    pg->content_h = 0;
}

void page_load_string(Page *pg, const char *html, size_t len, const char *label)
{
    page_free(pg);
    strncpy(pg->path, label, sizeof pg->path - 1);
    pg->path[sizeof pg->path - 1] = 0;

    Lay L;
    memset(&L, 0, sizeof L);
    L.pg = pg;
    L.width_cols = PAGE_COLS;
    L.cur_link = -1;
    layout_html(&L, html, len);
    end_line(&L);
    pg->content_h = L.y + 12;
    if (!pg->title[0]) {
        strncpy(pg->title, label, sizeof pg->title - 1);
        pg->title[sizeof pg->title - 1] = 0;
    }
}

bool page_load(Page *pg, const char *path)
{
    char full[96];
    snprintf(full, sizeof full, "rom:/%s", path);
    FILE *f = fopen(full, "rb");
    if (!f) {
        char msg[256];
        int n = snprintf(msg, sizeof msg,
            "<title>Not found</title><h1>404</h1><p>Could not open <code>%.40s</code>.</p>"
            "<p><a href=\"index.html\">Back to the home page</a></p>", path);
        page_load_string(pg, msg, (size_t)n, path);
        return false;
    }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)sz + 1);
    assert(buf);
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    buf[got] = 0;
    page_load_string(pg, buf, got, path);
    free(buf);
    return true;
}

const char *page_text(const Page *pg, uint32_t off) { return pg->arena + off; }
const char *page_link_href(const Page *pg, int link)
{
    return (link >= 0 && link < pg->n_links) ? pg->arena + pg->links[link].href_off : "";
}

int page_find_anchor(const Page *pg, const char *name)
{
    for (int i = 0; i < pg->n_anchors; i++)
        if (!strcmp(pg->arena + pg->anchors[i].name_off, name)) return pg->anchors[i].y;
    return -1;
}
