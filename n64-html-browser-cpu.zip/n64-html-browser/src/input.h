#ifndef INPUT_H
#define INPUT_H
#include <libdragon.h>

typedef struct {
    joypad_buttons_t pressed;   /* went down this frame */
    joypad_buttons_t held;
    int stick_x, stick_y;       /* about -80..80, y positive = up */
} Input;

#endif
