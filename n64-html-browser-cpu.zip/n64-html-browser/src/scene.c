/* First-person 3D scene viewer for <scene> elements (software renderer, CPU only). */
#include <libdragon.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "scene.h"
#include "util.h"
#include "config.h"
#include "gfx.h"

#define PLAYER_R   0.35f
#define EYE_H      1.55f
#define WALL_H     3.0f

void scene_init(Scene *s)
{
    memset(s, 0, sizeof *s);
    strcpy(s->name, "scene");
    s->floor_size = 24.0f;
    s->floor_col = 0x34343e;
    s->sky_col = 0x000000;
    s->ceil_col = 0x1a1a22;
}

bool scene_tag(Scene *s, const char *name, const char *a, size_t n)
{
    if (!strcmp(name, "box")) {
        if (s->n_boxes >= MAX_BOXES) return true;
        SceneBox *b = &s->boxes[s->n_boxes++];
        b->x = attr_float(a, n, "x", 0);
        b->y = attr_float(a, n, "y", 0);
        b->z = attr_float(a, n, "z", 0);
        b->w = attr_float(a, n, "w", 1);
        b->h = attr_float(a, n, "h", 1);
        b->d = attr_float(a, n, "d", 1);
        b->col = attr_color(a, n, "color", 0x888888);
        return true;
    }
    if (!strcmp(name, "pickup")) {
        if (s->n_pickups >= MAX_PICKUPS) return true;
        Pickup *p = &s->pickups[s->n_pickups++];
        p->x = attr_float(a, n, "x", 0);
        p->z = attr_float(a, n, "z", 0);
        p->col = attr_color(a, n, "color", 0x4fc3f7);
        return true;
    }
    if (!strcmp(name, "player")) {
        s->start_x = attr_float(a, n, "x", s->start_x);
        s->start_z = attr_float(a, n, "z", s->start_z);
        s->start_yaw = attr_float(a, n, "yaw", s->start_yaw);
        return true;
    }
    if (!strcmp(name, "floor")) {
        s->floor_col = attr_color(a, n, "color", s->floor_col);
        s->floor_size = attr_float(a, n, "size", s->floor_size);
        return true;
    }
    if (!strcmp(name, "ceiling")) {
        s->has_ceiling = true;
        s->ceil_col = attr_color(a, n, "color", s->ceil_col);
        return true;
    }
    if (!strcmp(name, "sky")) {
        s->sky_col = attr_color(a, n, "color", s->sky_col);
        return true;
    }
    return false;
}

/* ------------------------------------------------------------------ state */

static struct {
    float x, z, yaw;
    float battery;
    bool  flash;
    int   got;
    float time;
    char  msg[48];
    float msg_t;
} P;

static void say(const char *m) { snprintf(P.msg, sizeof P.msg, "%s", m); P.msg_t = 3.0f; }

void scene_start(Scene *s)
{
    memset(&P, 0, sizeof P);
    P.x = s->start_x;
    P.z = s->start_z;
    P.yaw = s->start_yaw;
    P.battery = 100.0f;
    P.flash = true;
    for (int i = 0; i < s->n_pickups; i++) s->pickups[i].taken = false;
    say("Find the baby crewmates.");
}

static float stick(int v)
{
    float f = v / 70.0f;
    if (f > 1) f = 1;
    if (f < -1) f = -1;
    return fabsf(f) < 0.12f ? 0.0f : f;
}

static bool blocked(const Scene *s, float x, float z)
{
    float lim = s->floor_size * 0.5f - PLAYER_R;
    if (x < -lim || x > lim || z < -lim || z > lim) return true;
    for (int i = 0; i < s->n_boxes; i++) {
        const SceneBox *b = &s->boxes[i];
        if (b->y > 1.6f || b->y + b->h < 0.2f) continue;   /* overhead or flat decal */
        if (fabsf(x - b->x) < b->w * 0.5f + PLAYER_R &&
            fabsf(z - b->z) < b->d * 0.5f + PLAYER_R) return true;
    }
    return false;
}

static int nearest_pickup(const Scene *s)
{
    int best = -1;
    float bd = 1.5f * 1.5f;
    for (int i = 0; i < s->n_pickups; i++) {
        if (s->pickups[i].taken) continue;
        float dx = s->pickups[i].x - P.x, dz = s->pickups[i].z - P.z;
        float d = dx * dx + dz * dz;
        if (d < bd) { bd = d; best = i; }
    }
    return best;
}

bool scene_update(Scene *s, const Input *in, float dt)
{
    if (in->pressed.b) return false;
    P.time += dt;
    if (P.msg_t > 0) P.msg_t -= dt;

    float turn = stick(in->stick_x);
    float fwd = stick(in->stick_y);
    float str = (in->held.c_right ? 1.0f : 0.0f) - (in->held.c_left ? 1.0f : 0.0f);

    P.yaw -= turn * 110.0f * dt;
    float rad = P.yaw * (float)M_PI / 180.0f;
    float sy = sinf(rad), cy = cosf(rad);
    float speed = in->held.r ? 4.2f : 2.4f;
    float vx = (-sy * fwd + cy * str) * speed * dt;
    float vz = (-cy * fwd - sy * str) * speed * dt;
    if (!blocked(s, P.x + vx, P.z)) P.x += vx;
    if (!blocked(s, P.x, P.z + vz)) P.z += vz;

    if (in->pressed.z && P.battery > 0) P.flash = !P.flash;
    if (P.flash) {
        P.battery -= (100.0f / 90.0f) * dt;
        if (P.battery <= 0) { P.battery = 0; P.flash = false; say("Flashlight is dead."); }
    }

    int near_i = nearest_pickup(s);
    if (near_i >= 0 && in->pressed.a) {
        s->pickups[near_i].taken = true;
        P.got++;
        P.battery += 25.0f;
        if (P.battery > 100) P.battery = 100;
        if (P.got == s->n_pickups) say("All baby crewmates rescued!");
        else say("Rescued a baby crewmate. +25% battery");
    }
    return true;
}

/* ---------------------------------------------------------------- drawing
 * Software renderer: a column raycaster over the scene's boxes (2D slab test),
 * with distance fog standing in for the flashlight. 160 columns, 2 px wide. */

#define COLS    (SCREEN_W / 2)
#define MAXHIT  24

static float zcol[COLS];

typedef struct { float t0, t1; int box, face; } Hit;

static inline float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

static inline uint16_t shade(uint32_t col, float k, float fog)
{
    float f = k * fog;
    return gfx_rgb((int)(((col >> 16) & 255) * f), (int)(((col >> 8) & 255) * f),
                   (int)((col & 255) * f));
}

static void vspan(surface_t *d, int x, int y0, int y1, uint16_t c)
{
    if (y0 < 0) y0 = 0;
    if (y1 > (int)d->height) y1 = (int)d->height;
    for (int y = y0; y < y1; y++) {
        uint16_t *p = gfx_row(d, y) + x;
        p[0] = c; p[1] = c;
    }
}

void scene_draw(surface_t *d, Scene *s)
{
    const int half = SCREEN_H / 2;
    const float focal = half / 0.7f;

    float fnear = 0.5f, ffar = 5.5f;
    if (P.flash) {
        fnear = 2.0f; ffar = 15.0f;
        if (P.battery < 15.0f && sinf(P.time * 37.0f) > 0.6f) { fnear = 0.5f; ffar = 4.0f; }
    }
#define FOG(dist) clamp01(1.0f - ((dist) - fnear) / (ffar - fnear))

    /* ceiling / sky and floor, one flat color per row */
    for (int y = 0; y < SCREEN_H; y++) {
        uint16_t c;
        if (y < half) {
            if (s->has_ceiling) {
                float dist = (WALL_H - EYE_H) * focal / (float)(half - y);
                c = shade(s->ceil_col, 1.0f, FOG(dist));
            } else c = gfx_hex(s->sky_col);
        } else {
            float dist = (y == half) ? 1000.0f : EYE_H * focal / (float)(y - half);
            c = shade(s->floor_col, 1.0f, FOG(dist));
        }
        gfx_fill(d, 0, y, SCREEN_W, y + 1, c);
    }

    float rad = P.yaw * (float)M_PI / 180.0f;
    float sn = sinf(rad), cs = cosf(rad);
    float fx = -sn, fz = -cs;     /* forward */
    float rx = cs,  rz = -sn;     /* right */

    for (int c = 0; c < COLS; c++) {
        float off = ((c + 0.5f) * 2.0f - SCREEN_W * 0.5f) / focal;
        float dx = fx + rx * off, dz = fz + rz * off;
        Hit hits[MAXHIT];
        int n = 0;
        zcol[c] = 1000.0f;

        for (int i = 0; i < s->n_boxes && n < MAXHIT; i++) {
            const SceneBox *b = &s->boxes[i];
            float x0 = b->x - b->w * 0.5f, x1 = b->x + b->w * 0.5f;
            float z0 = b->z - b->d * 0.5f, z1 = b->z + b->d * 0.5f;
            float ax0 = -1e9f, ax1 = 1e9f, az0 = -1e9f, az1 = 1e9f;
            if (fabsf(dx) < 1e-6f) { if (P.x < x0 || P.x > x1) continue; }
            else {
                float t0 = (x0 - P.x) / dx, t1 = (x1 - P.x) / dx;
                if (t0 > t1) { float t = t0; t0 = t1; t1 = t; }
                ax0 = t0; ax1 = t1;
            }
            if (fabsf(dz) < 1e-6f) { if (P.z < z0 || P.z > z1) continue; }
            else {
                float t0 = (z0 - P.z) / dz, t1 = (z1 - P.z) / dz;
                if (t0 > t1) { float t = t0; t0 = t1; t1 = t; }
                az0 = t0; az1 = t1;
            }
            float tmin = ax0 > az0 ? ax0 : az0;
            float tmax = ax1 < az1 ? ax1 : az1;
            if (tmax < tmin || tmin < 0.05f) continue;
            hits[n].t0 = tmin; hits[n].t1 = tmax; hits[n].box = i;
            hits[n].face = ax0 > az0 ? 0 : 1;
            n++;
        }
        /* far to near */
        for (int a = 1; a < n; a++) {
            Hit h = hits[a]; int k = a - 1;
            while (k >= 0 && hits[k].t0 < h.t0) { hits[k + 1] = hits[k]; k--; }
            hits[k + 1] = h;
        }
        for (int a = 0; a < n; a++) {
            const Hit *h = &hits[a];
            const SceneBox *b = &s->boxes[h->box];
            float top = b->y + b->h;
            int ytop = half - (int)((top - EYE_H) * focal / h->t0);
            int ybot = half - (int)((b->y - EYE_H) * focal / h->t0);
            float fog = FOG(h->t0);
            if (top < EYE_H) {                       /* visible top face */
                int yfar = half - (int)((top - EYE_H) * focal / h->t1);
                vspan(d, c * 2, yfar, ytop, shade(b->col, 1.0f, FOG(h->t1)));
            }
            vspan(d, c * 2, ytop, ybot, shade(b->col, h->face ? 0.80f : 0.62f, fog));
        }
        if (n) zcol[c] = hits[n - 1].t0;
    }

    /* pickups as little billboards */
    for (int i = 0; i < s->n_pickups; i++) {
        const Pickup *p = &s->pickups[i];
        if (p->taken) continue;
        float px = p->x - P.x, pz = p->z - P.z;
        float depth = px * fx + pz * fz;
        if (depth < 0.3f) continue;
        float lat = px * rx + pz * rz;
        float bob = 0.12f * sinf(P.time * 3.0f + i);
        int cx = SCREEN_W / 2 + (int)(lat / depth * focal);
        int hw = (int)(0.25f * focal / depth);
        int y0 = half - (int)((0.75f + bob - EYE_H) * focal / depth);
        int y1 = half - (int)((0.15f + bob - EYE_H) * focal / depth);
        int yv = y0 + (y1 - y0) / 5;
        float fog = FOG(depth);
        for (int x = cx - hw; x < cx + hw; x += 2) {
            int c = x / 2;
            if (x < 0 || c >= COLS || depth >= zcol[c]) continue;
            vspan(d, c * 2, y0, y1, shade(p->col, 1.0f, fog));
            vspan(d, c * 2, yv, yv + (y1 - y0) / 4, shade(0xbfefff, 1.0f, fog));
        }
    }

    /* ---- HUD ---- */
    gfx_fill(d, MARGIN_X, 18, MARGIN_X + 80, 30, gfx_rgb(20, 30, 40));
    int bw = (int)(76.0f * P.battery / 100.0f);
    gfx_fill(d, MARGIN_X + 2, 20, MARGIN_X + 2 + bw, 28,
             P.battery < 20 ? gfx_rgb(255, 74, 61) : gfx_rgb(91, 240, 140));
    gfx_fill(d, SCREEN_W / 2 - 1, SCREEN_H / 2 - 1, SCREEN_W / 2 + 1, SCREEN_H / 2 + 1,
             gfx_rgb(220, 235, 255));

    char buf[64];
    snprintf(buf, sizeof buf, "BABIES %d/%d", P.got, s->n_pickups);
    gfx_text(d, MARGIN_X, 38, buf, 255, 255, 255);
    snprintf(buf, sizeof buf, "%.36s", s->caption);
    gfx_text(d, MARGIN_X, 50, buf, 255, 255, 255);
    gfx_text(d, SCREEN_W - MARGIN_X - 15 * CHAR_W, 20, "B: back to page", 255, 255, 255);

    int ni = nearest_pickup(s);
    const char *line = NULL;
    if (ni >= 0) line = "[A] Rescue the baby crewmate";
    else if (P.msg_t > 0) line = P.msg;
    if (line) gfx_text(d, (SCREEN_W - (int)strlen(line) * CHAR_W) / 2, 190, line, 255, 255, 255);
    gfx_text(d, MARGIN_X, 222, "Stick:move/turn C<>:strafe R:run Z:light", 255, 255, 255);
}
