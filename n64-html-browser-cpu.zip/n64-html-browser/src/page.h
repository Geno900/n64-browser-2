#ifndef PAGE_H
#define PAGE_H
#include <libdragon.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "config.h"
#include "scene.h"

typedef enum { IT_TEXT, IT_RULE, IT_VBAR, IT_IMAGE, IT_SCENE } ItemType;
enum { F_BOLD = 1, F_ITALIC = 2, F_UNDER = 4, F_CODE = 8, F_THICK = 16 };

/* One drawable thing, already positioned in page coordinates (pixels). */
typedef struct {
    uint8_t  type, flags;
    int16_t  x, y, w, h;
    uint16_t len;      /* text length */
    int16_t  link;     /* index into links[], -1 = none */
    int16_t  aux;      /* image index or scene index, -1 = none */
    uint32_t off;      /* text offset in arena */
} Item;

typedef struct { uint32_t href_off; int16_t y0, y1; } Link;
typedef struct { uint32_t name_off; int16_t y; } Anchor;

typedef struct {
    char   *arena;   size_t arena_len, arena_cap;
    Item   *items;   int n_items,   cap_items;
    Link   *links;   int n_links,   cap_links;
    Anchor *anchors; int n_anchors, cap_anchors;
    sprite_t *images[MAX_IMAGES]; int n_images;
    Scene  scenes[MAX_SCENES];    int n_scenes;
    char   title[48];
    char   path[64];
    int    content_h;
} Page;

void        page_init(Page *pg);
void        page_free(Page *pg);                 /* releases sprites, keeps buffers */
bool        page_load(Page *pg, const char *path); /* false = not found (404 page is shown) */
void        page_load_string(Page *pg, const char *html, size_t len, const char *label);
const char *page_text(const Page *pg, uint32_t off);
const char *page_link_href(const Page *pg, int link);
int         page_find_anchor(const Page *pg, const char *name);   /* y or -1 */

/* render.c */
void page_draw(surface_t *d, const Page *pg, int scroll, int focus);
void ui_draw(surface_t *d, const Page *pg, int scroll, int focus, const char *toast);

#endif
