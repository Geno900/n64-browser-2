/* Draws a laid-out Page straight into the framebuffer (CPU only). */
#include <libdragon.h>
#include <stdio.h>
#include <string.h>
#include "page.h"
#include "config.h"
#include "gfx.h"

#define COL_BG     gfx_rgb(8, 10, 22)
#define COL_BAR    gfx_rgb(24, 40, 90)
#define COL_LINK   gfx_rgb(80, 200, 255)
#define COL_FOCUS  gfx_rgb(30, 90, 190)
#define COL_CODE   gfx_rgb(34, 36, 52)
#define COL_RULE   gfx_rgb(110, 120, 160)
#define COL_ITAL   gfx_rgb(150, 150, 180)
#define COL_UNDER  gfx_rgb(220, 220, 220)

static int clip_top, clip_bottom;

/* All rectangles go through here: clipped to the scrolling band. */
static void fill(surface_t *d, int x0, int y0, int x1, int y1, uint16_t c)
{
    if (y0 < clip_top) y0 = clip_top;
    if (y1 > clip_bottom) y1 = clip_bottom;
    gfx_fill(d, x0, y0, x1, y1, c);
}

static void frame(surface_t *d, int x, int y, int w, int h, int t, uint16_t c)
{
    fill(d, x, y, x + w, y + t, c);
    fill(d, x, y + h - t, x + w, y + h, c);
    fill(d, x, y, x + t, y + h, c);
    fill(d, x + w - t, y, x + w, y + h, c);
}

static void text(surface_t *d, int x, int top, const char *s, int r, int g, int b)
{
    gfx_text(d, x, top, s, r, g, b);
}

void page_draw(surface_t *d, const Page *pg, int scroll, int focus)
{
    int off = VIEW_TOP - scroll;
    clip_top = VIEW_TOP;
    clip_bottom = VIEW_BOTTOM;

    /* ---- pass 1: shapes ---- */
    for (int i = 0; i < pg->n_items; i++) {
        const Item *it = &pg->items[i];
        int sy = it->y + off;
        int h = (it->type == IT_TEXT) ? LINE_H : it->h;
        if (sy + h <= VIEW_TOP || sy >= VIEW_BOTTOM) continue;
        bool focused = it->link >= 0 && it->link == focus;

        switch (it->type) {
        case IT_TEXT: {
            int w = it->len * CHAR_W;
            if (focused) fill(d, it->x, sy, it->x + w, sy + LINE_H, COL_FOCUS);
            else if (it->flags & F_CODE) fill(d, it->x, sy, it->x + w, sy + LINE_H, COL_CODE);
            if (it->link >= 0) fill(d, it->x, sy + LINE_H - 2, it->x + w, sy + LINE_H - 1, COL_LINK);
            else if (it->flags & F_UNDER) fill(d, it->x, sy + LINE_H - 2, it->x + w, sy + LINE_H - 1, COL_UNDER);
            else if (it->flags & F_ITALIC) fill(d, it->x, sy + LINE_H - 2, it->x + w, sy + LINE_H - 1, COL_ITAL);
            break;
        }
        case IT_RULE:
        case IT_VBAR:
            fill(d, it->x, sy, it->x + it->w, sy + it->h, COL_RULE);
            break;
        case IT_IMAGE:
            /* CPU build draws a placeholder box for every image. */
            fill(d, it->x, sy, it->x + it->w, sy + it->h, gfx_rgb(18, 22, 40));
            frame(d, it->x, sy, it->w, it->h, 1, COL_RULE);
            if (focused) frame(d, it->x - 2, sy - 2, it->w + 4, it->h + 4, 2, COL_LINK);
            break;
        case IT_SCENE:
            fill(d, it->x, sy, it->x + it->w, sy + it->h, gfx_rgb(44, 8, 12));
            frame(d, it->x, sy, it->w, it->h, focused ? 2 : 1,
                  focused ? gfx_rgb(255, 220, 80) : gfx_rgb(200, 40, 40));
            break;
        }
    }

    /* ---- pass 2: text ---- */
    for (int i = 0; i < pg->n_items; i++) {
        const Item *it = &pg->items[i];
        int sy = it->y + off;
        int h = (it->type == IT_TEXT) ? LINE_H : it->h;
        if (sy + h <= VIEW_TOP || sy >= VIEW_BOTTOM) continue;
        const char *s = page_text(pg, it->off);

        switch (it->type) {
        case IT_TEXT:
            text(d, it->x, sy + 1, s, 255, 255, 255);
            if (it->flags & F_BOLD) text(d, it->x + 1, sy + 1, s, 255, 255, 255);   /* fake bold */
            break;
        case IT_IMAGE:
            if (it->len) {
                int cx = it->x + (it->w - it->len * CHAR_W) / 2;
                if (cx < it->x + 2) cx = it->x + 2;
                text(d, cx, sy + it->h / 2 - 4, s, 255, 255, 255);
            }
            break;
        case IT_SCENE: {
            text(d, it->x + (it->w - 12 * CHAR_W) / 2, sy + 8, "[ 3D SCENE ]", 255, 255, 255);
            text(d, it->x + (it->w - it->len * CHAR_W) / 2, sy + 20, s, 255, 255, 255);
            break;
        }
        default: break;
        }
    }
}

void ui_draw(surface_t *d, const Page *pg, int scroll, int focus, const char *toast)
{
    clip_top = 0;
    clip_bottom = SCREEN_H;
    int max_scroll = pg->content_h - VIEW_H;
    if (max_scroll < 0) max_scroll = 0;

    /* Repaint the bands above and below the page so partly scrolled text is hidden. */
    fill(d, 0, 0, SCREEN_W, VIEW_TOP, COL_BG);
    fill(d, 0, VIEW_BOTTOM, SCREEN_W, SCREEN_H, COL_BG);
    fill(d, 0, TITLE_Y, SCREEN_W, TITLE_Y + TITLE_H, COL_BAR);
    fill(d, 0, STATUS_Y, SCREEN_W, STATUS_Y + STATUS_H, COL_BAR);

    /* scroll bar */
    if (max_scroll > 0 && pg->content_h > 0) {
        int track = VIEW_H;
        int bar = track * VIEW_H / pg->content_h;
        if (bar < 8) bar = 8;
        int by = VIEW_TOP + (track - bar) * scroll / max_scroll;
        fill(d, SCREEN_W - 7, VIEW_TOP, SCREEN_W - 4, VIEW_BOTTOM, gfx_rgb(20, 24, 44));
        fill(d, SCREEN_W - 7, by, SCREEN_W - 4, by + bar, COL_RULE);
    }

    char buf[48];
    snprintf(buf, sizeof buf, "%.28s", pg->title);
    text(d, MARGIN_X, TITLE_Y + 3, buf, 255, 255, 255);
    int pct = max_scroll > 0 ? scroll * 100 / max_scroll : 100;
    snprintf(buf, sizeof buf, "%3d%%", pct);
    text(d, SCREEN_W - MARGIN_X - 4 * CHAR_W, TITLE_Y + 3, buf, 255, 255, 255);

    if (toast && toast[0]) {
        snprintf(buf, sizeof buf, "%.36s", toast);
    } else if (focus >= 0) {
        snprintf(buf, sizeof buf, "> %.34s", page_link_href(pg, focus));
    } else {
        snprintf(buf, sizeof buf, "A:open B:back Pad:links L/R:page");
    }
    text(d, MARGIN_X, STATUS_Y + 3, buf, 255, 255, 255);
}
