#ifndef UTIL_H
#define UTIL_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Attribute helpers: 'a'/'n' is the raw text between a tag name and '>'. */
bool     attr_get(const char *a, size_t n, const char *key, char *out, size_t cap);
float    attr_float(const char *a, size_t n, const char *key, float def);
int      attr_int(const char *a, size_t n, const char *key, int def);
uint32_t attr_color(const char *a, size_t n, const char *key, uint32_t def);
uint32_t parse_color(const char *s, uint32_t def);   /* returns 0xRRGGBB */

#endif
