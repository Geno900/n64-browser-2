#include "util.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

static bool sp(char c) { return isspace((unsigned char)c) != 0; }

bool attr_get(const char *a, size_t n, const char *key, char *out, size_t cap)
{
    size_t kl = strlen(key);
    size_t i = 0;
    while (i < n) {
        size_t start = i;
        while (i < n && (sp(a[i]) || a[i] == '/')) i++;
        size_t ns = i;
        while (i < n && !sp(a[i]) && a[i] != '=' && a[i] != '/') i++;
        size_t nl = i - ns;
        while (i < n && sp(a[i])) i++;

        size_t vs = 0, vl = 0;
        if (i < n && a[i] == '=') {
            i++;
            while (i < n && sp(a[i])) i++;
            if (i < n && (a[i] == '"' || a[i] == '\'')) {
                char q = a[i++];
                vs = i;
                while (i < n && a[i] != q) i++;
                vl = i - vs;
                if (i < n) i++;
            } else {
                vs = i;
                while (i < n && !sp(a[i])) i++;
                vl = i - vs;
                if (vl > 0 && a[vs + vl - 1] == '/' && i >= n) vl--;   /* <x a=1/> */
            }
        }
        if (nl == kl && strncasecmp(a + ns, key, kl) == 0) {
            if (cap > 0) {
                size_t c = vl < cap - 1 ? vl : cap - 1;
                memcpy(out, a + vs, c);
                out[c] = 0;
            }
            return true;
        }
        if (i == start) i++;   /* always make progress */
    }
    return false;
}

float attr_float(const char *a, size_t n, const char *key, float def)
{
    char b[32];
    if (!attr_get(a, n, key, b, sizeof b) || !b[0]) return def;
    return strtof(b, NULL);
}

int attr_int(const char *a, size_t n, const char *key, int def)
{
    char b[32];
    if (!attr_get(a, n, key, b, sizeof b) || !b[0]) return def;
    return (int)strtol(b, NULL, 10);
}

uint32_t attr_color(const char *a, size_t n, const char *key, uint32_t def)
{
    char b[32];
    if (!attr_get(a, n, key, b, sizeof b)) return def;
    return parse_color(b, def);
}

uint32_t parse_color(const char *s, uint32_t def)
{
    static const struct { const char *n; uint32_t c; } names[] = {
        {"black", 0x000000}, {"white", 0xffffff}, {"red", 0xcc2222},
        {"green", 0x22aa44}, {"blue", 0x2255cc}, {"yellow", 0xdddd33},
        {"orange", 0xdd8822}, {"purple", 0x8833aa}, {"gray", 0x808080},
        {"grey", 0x808080}, {"cyan", 0x33cccc}, {"magenta", 0xcc33cc},
        {"brown", 0x7a4a24}, {"pink", 0xee88aa},
    };
    if (!s || !*s) return def;
    if (s[0] == '#') {
        size_t n = strlen(s + 1);
        char *end;
        unsigned long v = strtoul(s + 1, &end, 16);
        if (*end) return def;
        if (n == 6) return (uint32_t)v;
        if (n == 3) {
            unsigned r = (v >> 8) & 15, g = (v >> 4) & 15, b = v & 15;
            return ((r * 17) << 16) | ((g * 17) << 8) | (b * 17);
        }
        return def;
    }
    for (size_t i = 0; i < sizeof names / sizeof names[0]; i++)
        if (strcasecmp(s, names[i].n) == 0) return names[i].c;
    return def;
}
