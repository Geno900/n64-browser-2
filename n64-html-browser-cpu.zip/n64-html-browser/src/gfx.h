/* Tiny CPU-only drawing helpers. No RDP, no RSP, no OpenGL: everything is
 * written straight into the 16-bit framebuffer, so any N64 emulator runs it. */
#ifndef GFX_H
#define GFX_H
#include <libdragon.h>
#include <stdint.h>
#include <string.h>
#include "config.h"

/* RGBA5551 pixel from 8-bit channels. */
static inline uint16_t gfx_rgb(int r, int g, int b)
{
    r = r < 0 ? 0 : (r > 255 ? 255 : r);
    g = g < 0 ? 0 : (g > 255 ? 255 : g);
    b = b < 0 ? 0 : (b > 255 ? 255 : b);
    return (uint16_t)(((r >> 3) << 11) | ((g >> 3) << 6) | ((b >> 3) << 1) | 1);
}

static inline uint16_t gfx_hex(uint32_t c)
{
    return gfx_rgb((c >> 16) & 255, (c >> 8) & 255, c & 255);
}

static inline uint16_t *gfx_row(surface_t *d, int y)
{
    return (uint16_t *)((uint8_t *)d->buffer + (size_t)y * d->stride);
}

/* Fill [x0,x1) x [y0,y1), clamped to the screen. */
static inline void gfx_fill(surface_t *d, int x0, int y0, int x1, int y1, uint16_t c)
{
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > (int)d->width) x1 = (int)d->width;
    if (y1 > (int)d->height) y1 = (int)d->height;
    if (x1 <= x0 || y1 <= y0) return;
    for (int y = y0; y < y1; y++) {
        uint16_t *p = gfx_row(d, y) + x0;
        for (int x = x0; x < x1; x++) *p++ = c;
    }
}

/* 8x8 built-in font, y = top of the glyph. Clipped horizontally here. */
static inline void gfx_text(surface_t *d, int x, int y, const char *s, int r, int g, int b)
{
    if (y < 0 || y + 8 > (int)d->height) return;
    while (x < 0 && *s) { x += 8; s++; }
    int maxc = ((int)d->width - x) / 8;
    if (maxc <= 0 || !*s) return;
    if (maxc > 79) maxc = 79;
    char buf[80];
    int n = 0;
    while (s[n] && n < maxc) { buf[n] = s[n]; n++; }
    buf[n] = 0;
    graphics_set_color(graphics_make_color(r, g, b, 255), 0);
    graphics_draw_text(d, x, y, buf);
}

#endif
