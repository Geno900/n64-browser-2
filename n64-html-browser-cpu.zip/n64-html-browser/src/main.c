#include <libdragon.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "config.h"
#include "gfx.h"
#include "input.h"
#include "page.h"
#include "scene.h"

typedef enum { MODE_PAGE, MODE_SCENE } Mode;
typedef struct { char path[64]; int scroll, focus; } HistEntry;

static Page page;
static Mode mode = MODE_PAGE;
static Scene *cur_scene;

static float scroll_f;
static int focus = -1;
static HistEntry hist[MAX_HISTORY];
static int hist_n;
static char toast[64];
static float toast_t;

static void set_toast(const char *msg)
{
    snprintf(toast, sizeof toast, "%s", msg);
    toast_t = 2.5f;
}

static int max_scroll(void)
{
    int m = page.content_h - VIEW_H;
    return m > 0 ? m : 0;
}

static void clamp_scroll(void)
{
    if (scroll_f < 0) scroll_f = 0;
    if (scroll_f > max_scroll()) scroll_f = (float)max_scroll();
}

static void ensure_visible(int link)
{
    if (link < 0 || link >= page.n_links) return;
    const Link *l = &page.links[link];
    if (l->y0 < scroll_f + 4) scroll_f = (float)l->y0 - 8;
    else if (l->y1 > scroll_f + VIEW_H - 4) scroll_f = (float)l->y1 - VIEW_H + 8;
    clamp_scroll();
}

static void split_href(const char *href, char *path, size_t pcap, char *frag, size_t fcap)
{
    if (!strncmp(href, "rom:/", 5)) href += 5;
    while (*href == '/' || (href[0] == '.' && href[1] == '/')) href += (*href == '/') ? 1 : 2;
    const char *hash = strchr(href, '#');
    size_t pl = hash ? (size_t)(hash - href) : strlen(href);
    if (pl >= pcap) pl = pcap - 1;
    memcpy(path, href, pl);
    path[pl] = 0;
    snprintf(frag, fcap, "%s", hash ? hash + 1 : "");
}

static void load_page(const char *path)
{
    if (!page_load(&page, path)) set_toast("File not found");
    scroll_f = 0;
    focus = -1;
}

static void navigate(const char *href)
{
    if (!strncmp(href, "scene:", 6)) {
        int idx = atoi(href + 6);
        if (idx >= 0 && idx < page.n_scenes) {
            cur_scene = &page.scenes[idx];
            scene_start(cur_scene);
            mode = MODE_SCENE;
        }
        return;
    }
    if (strstr(href, "://") || !strncmp(href, "mailto:", 7)) {
        set_toast("No network on N64");
        return;
    }

    char path[64], frag[32];
    split_href(href, path, sizeof path, frag, sizeof frag);

    if (path[0] && strcmp(path, page.path) != 0) {
        if (hist_n == MAX_HISTORY) {
            memmove(&hist[0], &hist[1], sizeof(HistEntry) * (MAX_HISTORY - 1));
            hist_n--;
        }
        snprintf(hist[hist_n].path, sizeof hist[hist_n].path, "%s", page.path);
        hist[hist_n].scroll = (int)scroll_f;
        hist[hist_n].focus = focus;
        hist_n++;
        load_page(path);
    }
    if (frag[0]) {
        int y = page_find_anchor(&page, frag);
        if (y >= 0) { scroll_f = (float)y - 4; clamp_scroll(); }
        else set_toast("Anchor not found");
    }
}

static void go_back(void)
{
    if (hist_n == 0) { set_toast("No history"); return; }
    HistEntry h = hist[--hist_n];
    load_page(h.path);
    scroll_f = (float)h.scroll;
    focus = h.focus;
    clamp_scroll();
}

static float stick_axis(int v)
{
    float f = v / 70.0f;
    if (f > 1) f = 1;
    if (f < -1) f = -1;
    return fabsf(f) < 0.15f ? 0.0f : f;
}

static bool link_visible(int l)
{
    const Link *k = &page.links[l];
    return k->y1 > scroll_f && k->y0 < scroll_f + VIEW_H;
}

static void focus_move(int dir)
{
    if (page.n_links == 0) return;
    if (focus < 0 || !link_visible(focus)) {
        int pick = -1;
        if (dir > 0) {
            for (int i = 0; i < page.n_links; i++)
                if (page.links[i].y0 >= scroll_f) { pick = i; break; }
        } else {
            for (int i = page.n_links - 1; i >= 0; i--)
                if (page.links[i].y1 <= scroll_f + VIEW_H) { pick = i; break; }
        }
        if (pick >= 0) { focus = pick; ensure_visible(focus); return; }
    }
    focus += dir;
    if (focus < 0) focus = 0;
    if (focus >= page.n_links) focus = page.n_links - 1;
    ensure_visible(focus);
}

static void update_page(const Input *in, float dt)
{
    float sy = stick_axis(in->stick_y);
    if (sy != 0) scroll_f -= sy * 240.0f * dt;
    if (in->held.c_down) scroll_f += 170.0f * dt;
    if (in->held.c_up)   scroll_f -= 170.0f * dt;
    if (in->pressed.r) scroll_f += VIEW_H - 22;
    if (in->pressed.l) scroll_f -= VIEW_H - 22;
    clamp_scroll();

    if (in->pressed.d_down) focus_move(+1);
    if (in->pressed.d_up)   focus_move(-1);
    if (in->pressed.a && focus >= 0) navigate(page_link_href(&page, focus));
    if (in->pressed.b || in->pressed.d_left) go_back();
    if (in->pressed.start) { hist_n = 0; load_page("index.html"); }

    if (toast_t > 0) { toast_t -= dt; if (toast_t <= 0) toast[0] = 0; }
}

static Input read_input(void)
{
    joypad_poll();
    Input in;
    joypad_inputs_t j = joypad_get_inputs(JOYPAD_PORT_1);
    in.pressed = joypad_get_buttons_pressed(JOYPAD_PORT_1);
    in.held = joypad_get_buttons_held(JOYPAD_PORT_1);
    in.stick_x = j.stick_x;
    in.stick_y = j.stick_y;
    return in;
}

int main(void)
{
    display_init(RESOLUTION_320x240, DEPTH_16_BPP, 3, GAMMA_NONE, FILTERS_RESAMPLE);
    joypad_init();
    dfs_init(DFS_DEFAULT_LOCATION);

    page_init(&page);
    load_page("index.html");

    uint32_t last = get_ticks_ms();
    while (1) {
        uint32_t now = get_ticks_ms();
        float dt = (now - last) / 1000.0f;
        last = now;
        if (dt > 0.1f) dt = 0.1f;

        Input in = read_input();
        if (mode == MODE_PAGE) update_page(&in, dt);
        else if (!scene_update(cur_scene, &in, dt)) mode = MODE_PAGE;

        surface_t *disp = display_get();
        if (mode == MODE_PAGE) {
            gfx_fill(disp, 0, 0, SCREEN_W, SCREEN_H, gfx_rgb(8, 10, 22));
            page_draw(disp, &page, (int)scroll_f, focus);
            ui_draw(disp, &page, (int)scroll_f, focus, toast);
        } else {
            scene_draw(disp, cur_scene);
        }
        display_show(disp);
    }
}
