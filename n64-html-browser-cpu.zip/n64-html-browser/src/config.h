#ifndef CONFIG_H
#define CONFIG_H

/* Screen and layout, in pixels. Content stays inside the TV-safe area. */
#define SCREEN_W      320
#define SCREEN_H      240

#define MARGIN_X      16
#define TITLE_Y       8
#define TITLE_H       14
#define VIEW_TOP      26
#define VIEW_BOTTOM   212
#define VIEW_H        (VIEW_BOTTOM - VIEW_TOP)
#define STATUS_Y      216
#define STATUS_H      14

/* Built-in debug font metrics. If text looks off on your build,
 * these three numbers are the only things to tweak. */
#define CHAR_W        8
#define LINE_H        11
#define TEXT_ASCENT   8

#define PAGE_COLS     ((SCREEN_W - 2 * MARGIN_X) / CHAR_W)

#define FONT_ID       FONT_BUILTIN_DEBUG_MONO

#define MAX_SCENES    8
#define MAX_IMAGES    16
#define MAX_HISTORY   16

#endif
