# N64 HTML Browser (libdragon)

A mini HTML browser for the Nintendo 64. Pages are plain `.html` files in `filesystem/`
that get packed into the ROM. A C layout engine parses and lays them out on the console.
A custom `<scene>` tag opens a first-person 3D view (modeled on the Impostor 3D Horror game).

## Build

1. Install [libdragon](https://github.com/DragonMinded/libdragon) (the `libdragon` CLI / Docker setup is easiest).
2. In this folder run `libdragon make` (or `make` if you have the toolchain installed natively).
3. Open `htmlbrowser.z64` in an emulator (ares, Ares, Project64) or copy it to a flash cart.

## Controls

Page view: D-pad up/down = pick link, A = open, B / D-left = back, stick or C up/down = scroll,
L/R = page up/down, Start = home.
3D scene: stick = walk/turn, C left/right = strafe, R = run, Z = flashlight, A = rescue, B = leave.

## Supported markup

`h1-h6 p div br hr center b strong i em u code pre blockquote ul ol li dl dt dd a img title`,
`&entities;`, `id` anchors and `#fragment` links, `<!-- comments -->`. `<script>` and `<style>` are skipped.
`<img src="x.png">` uses `assets/x.png` converted to a sprite, otherwise draws a placeholder box.

Scene tags (inside `<scene name caption size startx startz yaw floor ceiling sky>`):
`<box x z y w h d color>` (x,z = center, y = base), `<pickup x z color>`, `<floor>`, `<ceiling>`, `<sky>`, `<player>`.

## CPU-only rendering (this version)

This build does not use RDP, RSP microcode, rdpq or OpenGL. Everything is drawn by the CPU
straight into the 16-bit framebuffer (`src/gfx.h`), and the 3D view is a software raycaster
in `src/scene.c`. It should run in HLE emulators such as M64Plus FZ, not only paraLLEl/LLE.

Not in this version: image sprites (placeholder boxes are drawn), textured or lit 3D.

## Files

- `src/gfx.h` CPU drawing helpers (rects, 8x8 text)
- `src/page.c` tokenizer and layout engine
- `src/render.c` page and UI drawing (CPU)
- `src/scene.c` scene parsing, movement, collision, software raycaster
- `src/main.c` input, navigation, history, main loop
